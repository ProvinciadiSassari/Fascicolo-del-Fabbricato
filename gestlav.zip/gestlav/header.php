<div id="div_header">
    <img src="images/gestlav.png" />
</div>    